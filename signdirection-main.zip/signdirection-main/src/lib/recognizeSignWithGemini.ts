import { GoogleGenAI } from "@google/genai";

const GEMINI_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: GEMINI_KEY });

// Convert file to base64 inline data
async function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function recognizeSignWithGemini(file: File): Promise<string> {
  const base64Image = await fileToBase64(file);

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [
      {
        inlineData: {          mimeType: file.type,
          data: base64Image,
        },
      },
      {
        text: "Identify this hand sign in Indian Sign Language. Reply only with the most likely meaning or letter.",
      }
    ],
  });

  console.log("Gemini Response:", response.text);
  return response.text ?? "Not sure";
}
