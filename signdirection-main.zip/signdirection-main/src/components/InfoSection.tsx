export default function InfoSection() {
  return (
    <section className="text-center mt-20">
      <h2 className="text-3xl font-bold text-white">How It Works</h2>
      <p className="text-gray-300 mt-2">
        Our AI transforms sign language into speech instantly!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-12 px-20">
        <div className="p-6 rounded-xl bg-gray-900/50 shadow-lg text-white">
          📤 Image Upload
        </div>
        <div className="p-6 rounded-xl bg-gray-900/50 shadow-lg text-white">
          🧠 AI Interpretation
        </div>
        <div className="p-6 rounded-xl bg-gray-900/50 shadow-lg text-white">
          💬 Text Output
        </div>
        <div className="p-6 rounded-xl bg-gray-900/50 shadow-lg text-white">
          🔊 Voice Output
        </div>
      </div>
    </section>
  );
}
