import React, { useState } from "react";
import { recognizeSignWithGemini } from "../lib/recognizeSignWithGemini";

export default function SignImageWithGemini() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
    setResult(null);

    if (f) {
      const url = URL.createObjectURL(f);
      console.log("Selected:", url);
      setPreview(url);
    } else {
      setPreview(null);
    }
  };

  const onAnalyze = async () => {
    if (!file) return;
    setLoading(true);

    try {
      const res = await recognizeSignWithGemini(file);
      setResult(res);
    } catch (err) {
      console.error(err);
      setResult("Error analyzing image");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ textAlign: "center", padding: 20 }}>
      <input type="file" accept="image/*" onChange={onChange} />
      {preview && (
        <img
          src={preview}
          alt="preview"
          style={{
            maxWidth: 300,
            borderRadius: 10,
            margin: "10px auto",
            display: "block",
          }}
        />
      )}

      <button onClick={onAnalyze} disabled={!file || loading}>
        {loading ? "Analyzing..." : "Analyze Sign"}
      </button>

      {result && (
        <div style={{ marginTop: 15, fontSize: 18, fontWeight: "bold" }}>
          Result: {result}
        </div>
      )}
    </div>
  );
}
