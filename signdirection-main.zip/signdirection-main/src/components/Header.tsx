export default function Header() {
  return (
    <header className="text-center py-8">
      <h1 className="text-5xl font-extrabold text-sky-300 drop-shadow">
        Sign Language Direction
      </h1>
      <p className="mt-4 text-gray-300 text-lg">
        Experience the future of communication • AI-powered gesture interpretation • Realtime speech output
      </p>

      <div className="flex justify-center gap-6 mt-4 text-sm text-gray-400">
        <span>• Neural Processing</span>
        <span>• Voice Synthesis</span>
      </div>
    </header>
  );
}
