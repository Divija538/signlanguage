import { useState } from "react";
import { recognizeSignWithGemini } from "../lib/recognizeSignWithGemini";

export default function ImageUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    setFile(f || null);
    setPreview(f ? URL.createObjectURL(f) : null);
    setResult(null);
  };

  const onAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    const res = await recognizeSignWithGemini(file);
    setResult(res);
    setLoading(false);

    // Voice output
    const utter = new SpeechSynthesisUtterance(res);
    speechSynthesis.speak(utter);
  };

  return (
    <div className="bg-gray-900/40 p-6 rounded-xl border border-cyan-600 shadow-cyan-500/50 shadow-md w-[60%] mx-auto mt-10">
      <div className="text-center">
        {preview ? (
          <img src={preview} className="mx-auto max-w-xs rounded-lg"/>
        ) : (
          <div className="text-gray-500 py-20 border rounded-lg">
            Upload Sign Language Image
          </div>
        )}

        <input
          type="file"
          accept="image/*"
          onChange={onChange}
          className="mt-4 text-white"
        />

        <button
          disabled={!file || loading}
          onClick={onAnalyze}
          className="mt-4 px-6 py-2 bg-cyan-600 text-white rounded-full hover:bg-cyan-700"
        >
          {loading ? "Analyzing..." : "Analyze"}
        </button>

        {result && (
          <p className="mt-6 text-3xl font-bold text-green-400">
            {result}
          </p>
        )}
      </div>
    </div>
  );
}
