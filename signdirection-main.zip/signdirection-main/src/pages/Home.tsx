import Header from "../components/Header";
import InfoSection from "../components/InfoSection";
import ImageUpload from "../components/ImageUpload";

export default function Home() {
  return (
    <div className="min-h-screen text-white bg-[#050A15]">
      <Header />  
      <ImageUpload />
      <InfoSection />
      
      <footer className="mt-20 text-center text-gray-400 text-sm">
        Built with React + TypeScript + Gemini Vision API <br />
      </footer>
    </div>
  );
}
