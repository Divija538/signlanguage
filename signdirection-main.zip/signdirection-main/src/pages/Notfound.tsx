import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 text-slate-100">
      <h1 className="text-5xl font-bold mb-2">404</h1>
      <p className="text-lg mb-6">Page not found</p>

      <Link
        to="/"
        className="px-4 py-2 rounded-lg bg-blue-500 hover:bg-blue-600 transition text-white"
      >
        Go back home
      </Link>
    </div>
  );
};

export default NotFound;
